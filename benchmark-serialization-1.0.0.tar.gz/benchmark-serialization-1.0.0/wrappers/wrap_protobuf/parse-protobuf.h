#pragma once

#include "data.h"
#include "serializer.h"
#include "../sensordata.pb-c.h"

void protobuf_get_serializer(Serializer* s);