#pragma once

#include "data.h"
#include "serializer.h"

void c_get_serializer(Serializer*);