#pragma once

#include "data.h"
#include "serializer.h"
#include <json.h>

void jsonc_get_serializer(Serializer*);

