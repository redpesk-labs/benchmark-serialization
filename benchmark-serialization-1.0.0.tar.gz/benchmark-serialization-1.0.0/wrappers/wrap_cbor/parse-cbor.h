#pragma once

#include "data.h"
#include "serializer.h"
#include <cbor.h>

void cborc_get_serializer(Serializer*);

