#pragma once

#include "data.h"
#include "serializer.h"

void jsmn_get_serializer(Serializer*);