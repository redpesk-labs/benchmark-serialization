#pragma once

#include "data.h"
#include "serializer.h"
#include <json.h>

void fastjson_get_serializer(Serializer*);