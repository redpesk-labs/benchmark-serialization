#pragma once

#include "data.h"
#include "serializer.h"

#include <tirpc/rpc/xdr.h>

void xdr_get_serializer(Serializer*);

